﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPaddle : MonoBehaviour
{
    // Use this for initialization
    void Start () {
        GetComponentInChildren<ParticleSystem>().Stop();
    }

    // Update is called once per frame
    void Update() {

            if (Input.GetKeyDown("a"))
            {
            float zdown = transform.position.z + 128 * Time.deltaTime;
            transform.position = new Vector3(transform.position.x, 0, zdown);
        } else if (Input.GetKeyDown("s")) {
            float zup = transform.position.z - 128 * Time.deltaTime;
            transform.position = new Vector3(transform.position.x, 0, zup);
        }


    }
    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.name == "Ball")
        {
            Debug.Log("Collision");
            GetComponentInChildren<ParticleSystem>().Play();
        }
        else
        {
            GetComponentInChildren<ParticleSystem>().Stop();
        }
    }
    void OnCollisionExit(Collision col)
    {
        if (col.gameObject.name == "Ball")
        {
            Debug.Log("Collision Exit");
            GetComponentInChildren<ParticleSystem>().Stop();
        }
    }
}
