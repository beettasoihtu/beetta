﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPaddle : MonoBehaviour
{
    // Use this for initialization
    void Start () {
        GetComponentInChildren<ParticleSystem>().Play();
    }

    // Update is called once per frame
    void Update() {

            if (Input.GetKeyDown("a"))
            {
                Debug.Log("a");
            } else if (Input.GetKeyDown("s")) {
                Debug.Log("s");
            }

        transform.position = new Vector3(0.0f, floorHeight, 0.0f);
        transform.position = new Vector3(0.0f, floorHeight, 0.0f);
    }
    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.name == "Ball")
        {
            Debug.Log("Collision");
        }
    }
}
