﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpponentPaddle : MonoBehaviour
{
    public bool CanMoveUp;
    public bool CanMoveDown;

    // Use this for initialization
    void Start()
    {
        CanMoveUp = true;
        CanMoveDown = true;
        GetComponentInChildren<ParticleSystem>().Stop();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("d"))
        {
            if (CanMoveUp == true)
            {
                float zdown = transform.position.z + 128 * Time.deltaTime;
                transform.position = new Vector3(transform.position.x, 0, zdown);
            }
        }
        else if (Input.GetKeyDown("f"))
        {
            if (CanMoveDown == true)
            {
                float zup = transform.position.z - 128 * Time.deltaTime;
                transform.position = new Vector3(transform.position.x, 0, zup);
            }
        }


    }
    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.name == "Ball")
        {
            Debug.Log("Collision");
            GetComponentInChildren<ParticleSystem>().Play();
        }else if (col.gameObject.name == "BumperTop")
        {
            CanMoveUp = false;
            Debug.Log("Collision Up");
        }else if (col.gameObject.name == "BumperBottom")
        {
            CanMoveDown = false;
        }
    }
    void OnCollisionExit(Collision col)
    {
        if (col.gameObject.name == "Ball")
        {
           Debug.Log("Collision Exit");
           GetComponentInChildren<ParticleSystem>().Stop();
        }else if (col.gameObject.name == "BumperTop")
        {
            CanMoveUp = true;
        }else if (col.gameObject.name == "BumperBottom")
        {
            CanMoveDown = true;
        }
    }
}
