﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallHandler : MonoBehaviour {
    public Rigidbody rigid;
    ScoreHandler score;
    // Use this for initialization
    void Start () {
        rigid = GetComponent<Rigidbody>();
        rigid.AddForce(Vector3.left * 200 + Vector3.forward * 100);
        score = GetComponent<ScoreHandler>();
    }
	
	// Update is called once per frame
	void Update () {
        rigid = GetComponent<Rigidbody>();
        if (Mathf.Abs(rigid.velocity.x) < 40)
        {
            Vector3 shrt = rigid.velocity;
            rigid.velocity = new Vector3(shrt.x + 0.001f / Time.deltaTime * Mathf.Sign(shrt.x), shrt.y, shrt.z);
        }

        transform.position = new Vector3(transform.position.x, 0, transform.position.z);

    }

    void OnCollisionEnter(Collision col)
    {
        score = GetComponent<ScoreHandler>();
        if (col.gameObject.name != "BumperLeft" && col.gameObject.name != "BumperRight")
        {
            if (Mathf.Abs(rigid.velocity.z) < 15)
            {
                Vector3 shrt = rigid.velocity;
                rigid.AddForce(Vector3.forward * 250 * Mathf.Sign(shrt.z));
            }
        }
        else
        {
            if (col.gameObject.name == "BumperLeft")
            {
                score.addPointForOpponent();
                Debug.Log("Left Goal");
               transform.position = Vector3.MoveTowards(transform.position, new Vector3(0.0f, 0.0f, 0.0f), 1000 * Time.deltaTime);
            }
            else if (col.gameObject.name == "BumperRight")
            {
                score.addPointForPlayer();
                Debug.Log("Right Goal");
                transform.position = Vector3.MoveTowards(transform.position, new Vector3(0.0f, 0.0f, 0.0f), 1000 * Time.deltaTime);
            }

        }
    }
}
