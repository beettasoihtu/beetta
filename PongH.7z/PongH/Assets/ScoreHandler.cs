﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreHandler : MonoBehaviour {

    private float playerScore;
    private float opponentScore;
    public string scoreText;

    public void addPointForPlayer()
        {
        playerScore += 1;
        }
    public void addPointForOpponent()
        {
        opponentScore += 1;
        }
    // Use this for initialization
    void Start () {
        playerScore = 0.0f;
        opponentScore = 0.0f;
        GetComponent<TextMesh>().text = "Score: " + playerScore + "-" + opponentScore;
    }
	
	// Update is called once per frame
	void Update () {
        GetComponent<TextMesh>().text = "Score: " + playerScore + "-" + opponentScore;
    }
}
