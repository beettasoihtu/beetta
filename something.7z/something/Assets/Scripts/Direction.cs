﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Direction
{
    North,
    East,
    South,
    West
}
//http://www.lessmilk.com/tutorial/space-shooter-unity-2