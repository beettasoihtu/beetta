﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameHandler : MonoBehaviour {

    public World worldPrefab;
    private World worldInstance;

    // Use this for initialization
    private void Start()
    {
        BeginGame();
    }

    // Update is called once per frame
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            RestartGame();
        }
    }

    private void BeginGame() {
        worldInstance = Instantiate(worldPrefab) as World;
        StartCoroutine(worldInstance.Generate());
    }

    private void RestartGame() {
        StopAllCoroutines();
        Destroy(worldInstance.gameObject);
        BeginGame();
    }

}
//dovoo1