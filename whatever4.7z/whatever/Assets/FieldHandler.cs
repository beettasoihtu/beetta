﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class FieldHandler : MonoBehaviour, IDropHandler, IPointerEnterHandler, IPointerExitHandler  {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void OnPointerEnter(PointerEventData eventData)
    {
    }

    public void OnPointerExit(PointerEventData eventData)
    {
    }

    public void OnDrop(PointerEventData eventData)
    {
        Dragging drag = eventData.pointerDrag.GetComponent<Dragging>();
        if (drag != null &&  this.transform.childCount < 6)
        {
            drag.handToReturnTo = this.transform;
        }
    }
}
