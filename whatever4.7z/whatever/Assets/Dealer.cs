﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Dealer : MonoBehaviour
{

    public GameObject card;
    private List<GameObject> deck = new List<GameObject>();
    Deck physicalDeck;


    // Use this for initialization
    void Start()
    {
        physicalDeck = FindObjectOfType(typeof(Deck)) as Deck;
        for (int i = 0; i < 10; i++)
        {
            GameObject newCard = Instantiate(card);
            newCard.transform.SetParent(this.transform);
            newCard.GetComponent<Dragging>().id = i;
            deck.Add(newCard);
            physicalDeck.AddCardsToDeck(1.0f);
        }
        this.transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, physicalDeck.dealerPositionShouldBe());
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("a"))
        {
            GameObject hand = GameObject.Find("Hand");
            //Debug.Log(deck.Count);
            if (deck.Count >= 5)
            {
                for (int i = 0; i < 5; i++)
                {
                    if (hand.transform.childCount < 6)
                    {
                        deck[i].GetComponent<RawImage>().texture = GameObject.Find("CardFront").GetComponent<RawImage>().texture;
                        deck[i].GetComponent<RawImage>().color = Random.ColorHSV();
                        deck[i].transform.SetParent(hand.transform);
                        GameObject newCard = Instantiate(card);
                        newCard.GetComponent<Dragging>().id = -1;
                        deck[i] = newCard;
                    }
                }
                for (int i = 0; i < deck.Count; i++)
                {
                    if (deck[i].GetComponent<Dragging>().id == -1)
                    {
                        deck.Remove(deck[i]);
                        physicalDeck.RemoveCardsFromDeck(1.0f);
                        i--;
                    }
                }
                this.transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, physicalDeck.dealerPositionShouldBe());
            }
            else
            {
                for (int i = 0; i < deck.Count; i++)
                {
                    if (hand.transform.childCount < 6)
                    {
                        deck[i].GetComponent<RawImage>().texture = GameObject.Find("CardFront").GetComponent<RawImage>().texture;
                        deck[i].GetComponent<RawImage>().color = Random.ColorHSV();
                        deck[i].transform.SetParent(hand.transform);
                        GameObject newCard = Instantiate(card);
                        newCard.GetComponent<Dragging>().id = -1;
                        deck[i] = newCard;
                    }
                }
                for (int i = 0; i < deck.Count; i++)
                {
                    if (deck[i].GetComponent<Dragging>().id == -1)
                    {
                        deck.Remove(deck[i]);
                        physicalDeck.RemoveCardsFromDeck(1.0f);
                        i--;
                    }
                }
                this.transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, physicalDeck.dealerPositionShouldBe());
            }
            for (int i = 0; i < hand.transform.childCount; i++)
            {
                hand.transform.GetChild(i).transform.localPosition = new Vector3(hand.transform.GetChild(i).transform.localPosition.x, hand.transform.GetChild(i).transform.localPosition.y, 0.0f);
            }
            //Debug.Log(physicalDeck.dealerPositionShouldBe());
            deck[0].transform.localPosition = new Vector3(deck[0].transform.localPosition.x, deck[0].transform.localPosition.y, 0.0f);
        }

        if (Input.GetKeyDown("s"))
        {
            for (int i = 0; i < this.transform.childCount; i++)
            {
                deck[i].transform.localPosition = new Vector3(deck[i].transform.localPosition.x, deck[i].transform.localPosition.y, 0.0f);
            }
            string orderlog = "";
            for (int i = 0; i < deck.Count; i++)
            {
                orderlog += deck[i].GetComponent<Dragging>().id;
                orderlog += " ";
            }
            Debug.Log(orderlog);
            for (int i = 0; i < deck.Count; i++)
            {
                GameObject temp = deck[i];
                int randomIndex = Random.Range(i, deck.Count);
                deck[i] = deck[randomIndex];
                int oldSiblingIndex = deck[i].transform.GetSiblingIndex();
                deck[i].transform.SetSiblingIndex(deck[randomIndex].transform.GetSiblingIndex());
                deck[randomIndex] = temp;
                deck[randomIndex].transform.SetSiblingIndex(oldSiblingIndex);
            }

            orderlog = "";
            for (int i = 0; i < deck.Count; i++)
            {
                orderlog += deck[i].GetComponent<Dragging>().id;
                orderlog += " ";
            }
            Debug.Log(orderlog);
        }
        if (Input.GetKeyDown("d"))
        {
            GameObject hand = GameObject.Find("Hand");
            if (hand.transform.childCount < 6 && deck.Count != 0)
            {
                //GameObject placeholder = new GameObject();
                //placeholder.transform.SetParent(hand.transform);
                //LayoutElement le = placeholder.AddComponent<LayoutElement>();
                //le.preferredWidth = this.GetComponent<LayoutElement>().preferredWidth;
                //le.preferredHeight = this.GetComponent<LayoutElement>().preferredHeight;
                //le.flexibleWidth = 0;
                //le.preferredHeight = 0;

                //deck[0].transform.Translate(placeholder.transform.position*0.2f);

                deck[0].GetComponent<RawImage>().texture = GameObject.Find("CardFront").GetComponent<RawImage>().texture;
                deck[0].GetComponent<RawImage>().color = Random.ColorHSV();
                //placeholder = deck[0];
                deck[0].transform.SetParent(hand.transform);
                deck.Remove(deck[0]);
                for (int i = 0; i < hand.transform.childCount; i++)
                {
                    hand.transform.GetChild(i).transform.localPosition = new Vector3(hand.transform.GetChild(i).transform.localPosition.x, hand.transform.GetChild(i).transform.localPosition.y, 0.0f);
                }
                physicalDeck.RemoveCardsFromDeck(1.0f);
                deck[0].transform.localPosition = new Vector3(deck[0].transform.localPosition.x, deck[0].transform.localPosition.y, 0.0f);
                this.transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, physicalDeck.dealerPositionShouldBe());
            }
            //Debug.Log(physicalDeck.dealerPositionShouldBe());
            deck[0].transform.localPosition = new Vector3(deck[0].transform.localPosition.x, deck[0].transform.localPosition.y, 0.0f);

        }
        if (Input.GetKeyDown("f"))
        {
            for (int i = 0; i < 10; i++)
            {
                GameObject newCard = Instantiate(card);
                newCard.transform.SetParent(this.transform);
                newCard.GetComponent<Dragging>().id = i;
                deck.Add(newCard);
                physicalDeck.AddCardsToDeck(1.0f);
            }
            //Debug.Log(physicalDeck.dealerPositionShouldBe());
            this.transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, physicalDeck.dealerPositionShouldBe());
        }
        if (Input.GetKeyDown("g"))
        {
            GameObject hand = GameObject.Find("Hand");
            if (hand.transform.childCount != 0)
            {
                //Debug.Log(hand.transform.childCount);
                for (int i = hand.transform.childCount - 1; i >= 0; i--)
                {
                     GameObject.Destroy(hand.transform.GetChild(i).gameObject);
                }
                //Debug.Log(hand.transform.childCount);
            }
        }
        if (deck.Count == 0)
        {
            physicalDeck.deckRendererOff();
        }
        else
        {
            physicalDeck.deckRendererOn();
        }
    }
}