﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dealer : MonoBehaviour {

    public GameObject card;
    private List<GameObject> deck = new List<GameObject>();


    // Use this for initialization
    void Start () {
        for (int i = 0; i < 10; i++)
        {
            GameObject newcard = Instantiate(card);
            newcard.transform.SetParent(this.transform);
            newcard.GetComponent<Dragging>().id = i;
            deck.Add(newcard);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("a"))
        {
            Debug.Log(deck.Count);
            if (deck.Count >= 5)
            {

                for (int i = 5 - 1; i >= 0; i--)
                {
                    if (GameObject.Find("Hand").transform.childCount <= 6)
                    {
                        deck[i].transform.SetParent(GameObject.Find("Hand").transform);
                        deck.Remove(deck[i]);
                    }
                }
            }
        }
        if (Input.GetKeyDown("s"))
        {
            string orderlog = "";
            for (int i = 0; i < deck.Count; i++)
            {
                orderlog += deck[i].GetComponent<Dragging>().id;
                orderlog += " ";
            }

            orderlog = "";
            for (int i = 0; i < deck.Count; i++)
            {
                orderlog += deck[i].GetComponent<Dragging>().id;
                orderlog += " ";
            }
            Debug.Log(orderlog);
        }
    }
}
