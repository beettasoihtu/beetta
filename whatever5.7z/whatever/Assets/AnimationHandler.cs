﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationHandler : MonoBehaviour {


    Animation deal;
    // Use this for initialization
    void Start () {
       // deal = this.GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

//https://www.youtube.com/watch?v=s7EIp-OqVyk
//https://www.youtube.com/watch?v=ts24UWC0mY4
//https://www.youtube.com/watch?v=JeZkctmoBPw
//https://www.youtube.com/watch?v=aJOH0Jlo4YA

//https://www.youtube.com/watch?v=4cLvXh8Fp68
//https://www.youtube.com/watch?v=3HKwtUz807c&list=PLNa78yuO2qxW41wU1VBPp4uK3Vr5K4thJ&index=5