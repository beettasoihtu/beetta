﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Dragging : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    public Transform handToReturnTo;
    GameObject placeholder = null;
    private int oldSiblingIndex;
    public int id;
    public Transform _transform;

    // Use this for initialization
    void Start () {
        _transform = this.transform;
        RawImage image = this.GetComponent<RawImage>();
        image.texture = GameObject.Find("Cardback").GetComponent<RawImage>().texture;
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void OnBeginDrag(PointerEventData eventData)
    {
        placeholder = new GameObject();
        placeholder.transform.SetParent( this.transform.parent );
        LayoutElement le = placeholder.AddComponent<LayoutElement>();
        le.preferredWidth = this.GetComponent<LayoutElement>().preferredWidth;
        le.preferredHeight = this.GetComponent<LayoutElement>().preferredHeight;
        le.flexibleWidth = 0;
        le.preferredHeight = 0;

        placeholder.transform.SetSiblingIndex(this.transform.GetSiblingIndex());

        oldSiblingIndex = this.transform.GetSiblingIndex();
        //for (int i = 0; i < this.transform.parent.childCount; i++)
        //{
        //if (this.transform.parent.GetChild(i) == this)
        //{
        //this.tranform.parent.GetChild(i)
        //}
        //}


        //Debug.Log("On Begin Drag");
        handToReturnTo = this.transform.parent;
        this.transform.SetParent(this.transform.parent.parent);

        GetComponent<CanvasGroup>().blocksRaycasts = false;
    }

    public void OnDrag(PointerEventData eventData)
    {
    //Debug.Log("On Drag");
        this.transform.position = eventData.position;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        if (placeholder != null)
        {
            Destroy(placeholder);
        }
    //Debug.Log("On Exit Drag");
        this.transform.SetParent(handToReturnTo);
        this.transform.SetSiblingIndex(oldSiblingIndex);
        GetComponent<CanvasGroup>().blocksRaycasts = true;
    }
}
