﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Deck : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void AddCardsToDeck(float numberOfAddedCards)
    {
        transform.localScale = new Vector3(transform.localScale.x, transform.localScale.y, transform.localScale.z + numberOfAddedCards);
        transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, transform.localPosition.z - (numberOfAddedCards/2));
    }
    public void RemoveCardsFromDeck(float numberOfRemovedCards)
    {
        transform.localScale = new Vector3(transform.localScale.x, transform.localScale.y, transform.localScale.z - numberOfRemovedCards);
        transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, transform.localPosition.z + (numberOfRemovedCards/2));
    }

    public float dealerPositionShouldBe()
    {
        return (2*transform.localPosition.z) -1;
    }

    public void deckRendererOff()
    {
        Renderer rend = GetComponent<Renderer>();
        rend.enabled = false;
    }

    public void deckRendererOn()
    {
        Renderer rend = GetComponent<Renderer>();
        rend.enabled = true;
    }
}
